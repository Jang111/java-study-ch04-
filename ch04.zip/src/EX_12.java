
public class EX_12 {

	public static void main(String[] args) {
		int sum=0;;
		int i;
		for(i=0;i<10;i++) {
			sum=sum+(i+1);
			System.out.printf("1���� %2d������ ��: %2d%n",i+1,sum);
		}
		
		for(int j=0,k=9;j<10;j++,k--) {
			System.out.printf("%2d %2d%n",j+1,k+1);
		}
	}
}
