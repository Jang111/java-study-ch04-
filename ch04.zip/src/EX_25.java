
public class EX_25 {

	public static void main(String[] args) {
		for(int i=0;i<100;i++) {
			System.out.printf("i=%d",i+1);
			
			int tmp = i+1;
			
			do {
				if(tmp%10%3==0 && tmp%10!=0) {
					System.out.print("¦");
				}
			}while((tmp/=10)!=0);
			
			System.out.println();	
		}
	}
}

