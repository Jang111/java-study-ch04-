import java.util.*;
public class EX_21 {

	public static void main(String[] args) {
		int num=0;
		int sum=0;
		System.out.print("���ڸ� �Է��ϼ���.(��:12345)>");
		Scanner scanner = new Scanner(System.in);
		String tmp = scanner.nextLine();
		num = Integer.parseInt(tmp);
		
		while(num!=0) {
			sum+=(num%10);
			System.out.println("sum= "+sum+" num= "+num);
			num/=10;
		}
		System.out.printf("�� �ڸ����� ��: %d",sum);
	}
}

