
public class EX_20 {

	public static void main(String[] args) {
		int i=11;
		System.out.println("ī��Ʈ�ٿ��� �����մϴ�.");
		
		while(i>0) {
			i--;
			System.out.println(i);
			
			for(int j=0;j<2000_000_000;j++) {
				
			}
			
		}
		
		System.out.println("GAME OVER");
	}
}

