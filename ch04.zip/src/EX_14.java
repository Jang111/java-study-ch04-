
public class EX_14 {

	public static void main(String[] args) {
		int i,k;
		
		for(i=0;i<5;i++) {
			for(k=0;k<i+1;k++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
