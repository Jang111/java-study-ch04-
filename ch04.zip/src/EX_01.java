
public class EX_01 {

	public static void main(String[] args) {
		int x=0;
		System.out.printf("x=%d�϶�, ���ΰ���?%n",x);
		
		if(x==0) {
			System.out.printf("x==0%n");
		}
		if(x!=0) {
			System.out.printf("x!=0%n");
		}
		if(!(x==0)) {
			System.out.printf("!(x==0)%n");
		}
		if(!(x!=0)) {
			System.out.printf("!(x!=0)%n");
		}

	}

}
